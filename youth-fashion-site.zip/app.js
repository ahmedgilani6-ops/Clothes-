
const sampleProducts = [
  {"id":1,"title":"تيشيرت كاجوال","price":25,"image":"https://images.unsplash.com/photo-1520975914206-0a4b3b6f7f3a?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder","sizes":["S","M","L"],"color":"أسود"},
  {"id":2,"title":"جاكيت خفيف","price":45,"image":"https://images.unsplash.com/photo-1514996937319-344454492b37?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder","sizes":["M","L","XL"],"color":"رمادي"},
  {"id":3,"title":"بنطال جينز","price":35,"image":"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder","sizes":["32","34","36"],"color":"أزرق"},
  {"id":4,"title":"حذاء رياضي","price":60,"image":"https://images.unsplash.com/photo-1519744792095-2f2205e87b6f?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder","sizes":["40","41","42"],"color":"أبيض"},
  {"id":5,"title":"قميص رسمي","price":30,"image":"https://images.unsplash.com/photo-1520975914206-0a4b3b6f7f3a?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder","sizes":["M","L"],"color":"أبيض"},
  {"id":6,"title":"كاب شبابي","price":12,"image":"https://images.unsplash.com/photo-1503342452485-86f7f7a1b7e0?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder","sizes":["One Size"],"color":"أسود"}
];

const productsGrid = document.getElementById('products-grid');
const cartBtn = document.getElementById('cart-btn');
const cartDrawer = document.getElementById('cart-drawer');
const closeCartBtn = document.getElementById('close-cart');
const cartCountEl = document.getElementById('cart-count');
const cartItemsEl = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');
const checkoutBtn = document.getElementById('checkout-btn');

let cart = JSON.parse(localStorage.getItem('cart_v1')) || [];

function saveCart(){ localStorage.setItem('cart_v1', JSON.stringify(cart)); updateCartUI(); }

function formatPrice(val){ return val + ' د.ل'; }

function renderProducts(){
  sampleProducts.forEach(p=>{
    const col = document.createElement('div'); col.className='col-12 col-sm-6 col-lg-4';
    col.innerHTML = `
      <div class="card card-product">
        <img src="${p.image}" class="card-img-top product-img" alt="${p.title}">
        <div class="card-body">
          <h5 class="card-title">${p.title}</h5>
          <p class="mb-1 text-muted small">${p.color}</p>
          <div class="d-flex justify-content-between align-items-center">
            <div class="price">${formatPrice(p.price)}</div>
            <button class="btn btn-sm btn-outline-dark add-to-cart" data-id="${p.id}">أضف للسلة</button>
          </div>
        </div>
      </div>
    `;
    productsGrid.appendChild(col);
  });
  document.querySelectorAll('.add-to-cart').forEach(btn=>{
    btn.addEventListener('click', e=>{
      const id = Number(e.target.dataset.id);
      addToCart(id);
    });
  });
}

function addToCart(id){
  const prod = sampleProducts.find(p=>p.id===id);
  if(!prod) return;
  const existing = cart.find(i=>i.id===id);
  if(existing){ existing.qty += 1; } else { cart.push({id:prod.id,title:prod.title,price:prod.price,qty:1}); }
  saveCart();
  alert('تم إضافة المنتج إلى السلة');
}

function updateCartUI(){
  cartCountEl.textContent = cart.reduce((s,i)=>s+i.qty,0);
  cartItemsEl.innerHTML = '';
  if(cart.length===0){ cartItemsEl.innerHTML = '<div class="text-center text-muted">السلة فارغة</div>'; cartTotalEl.textContent='0 د.ل'; return; }
  cart.forEach(item=>{
    const div = document.createElement('div');
    div.className='d-flex align-items-center mb-3';
    div.innerHTML = `
      <div class="flex-grow-1">
        <div><strong>${item.title}</strong></div>
        <div class="small text-muted">${formatPrice(item.price)} × ${item.qty}</div>
      </div>
      <div class="text-end">
        <button class="btn btn-sm btn-outline-secondary me-1 dec" data-id="${item.id}">-</button>
        <button class="btn btn-sm btn-outline-secondary me-1 inc" data-id="${item.id}">+</button>
        <button class="btn btn-sm btn-danger del" data-id="${item.id}">حذف</button>
      </div>
    `;
    cartItemsEl.appendChild(div);
  });
  document.querySelectorAll('.inc').forEach(b=>b.addEventListener('click', e=>{ changeQty(e.target.dataset.id,1); }));
  document.querySelectorAll('.dec').forEach(b=>b.addEventListener('click', e=>{ changeQty(e.target.dataset.id,-1); }));
  document.querySelectorAll('.del').forEach(b=>b.addEventListener('click', e=>{ removeItem(e.target.dataset.id); }));
  const total = cart.reduce((s,i)=>s + i.price * i.qty,0);
  cartTotalEl.textContent = total + ' د.ل';
}

function changeQty(id,delta){
  const idx = cart.findIndex(i=>i.id===Number(id));
  if(idx===-1) return;
  cart[idx].qty += delta;
  if(cart[idx].qty <= 0) cart.splice(idx,1);
  saveCart();
}
function removeItem(id){ cart = cart.filter(i=>i.id!==Number(id)); saveCart(); }

cartBtn.addEventListener('click', ()=>{ cartDrawer.classList.add('open'); updateCartUI(); });
closeCartBtn.addEventListener('click', ()=>{ cartDrawer.classList.remove('open'); });
checkoutBtn.addEventListener('click', ()=>{
  if(cart.length===0){ alert('السلة فارغة'); return; }
  const checkoutModal = new bootstrap.Modal(document.getElementById('checkoutModal')); checkoutModal.show();
});

document.getElementById('checkout-form').addEventListener('submit', function(e){
  e.preventDefault();
  if(!this.checkValidity()) { this.classList.add('was-validated'); return; }
  const order = {
    id: 'ORD' + Date.now(),
    name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    address: document.getElementById('address').value,
    items: cart,
    total: cart.reduce((s,i)=>s+i.price*i.qty,0),
    cod: document.getElementById('cod').checked
  };
  // هنا نحفظ الطلب محليًا كمثال. في تطبيق حقيقي أرسل الطلب لخادم/قاعدة بيانات.
  const orders = JSON.parse(localStorage.getItem('orders_v1')||'[]');
  orders.push(order);
  localStorage.setItem('orders_v1', JSON.stringify(orders));
  cart = []; saveCart();
  bootstrap.Modal.getInstance(document.getElementById('checkoutModal')).hide();
  alert('تم تسجيل الطلب. رقم الطلب: ' + order.id + '\nسوف نتواصل معك عبر الواتساب.');
});

renderProducts();
updateCartUI();
